ROCK HOUSE 49 — WEBSITE FILES

Upload these files to your GitHub repository:
1. index.html
2. style.css
3. ministry-photo.jpg (your own photo)

On GitHub:
- Open your rock-house-49 repository.
- Choose Add file -> Upload files.
- Upload the files.
- Tap Commit changes.
- Wait a minute or two for GitHub Pages to rebuild.

Your current site address:
https://alexpearson8972-hash.github.io/rock-house-49/

IMPORTANT:
- The email address in the site is a placeholder: rockhouse49ministry@gmail.com
- Change it to your real ministry email before publishing if that is not your address.
- The phone number is the number shown in your supplied ministry graphic.
