ROCK HOUSE 49 WEBSITE
======================

Files:
- index.html
- ministry-*.jpeg/webp image files

Open index.html in a browser to preview the site.

BEFORE PUBLISHING:
1. Replace the placeholder mailto form action with a real booking-form endpoint or email.
2. Confirm the public ministry name, phone number, biography, affiliations, and credentials.
3. Add your final logo/social links.
4. Add a custom domain and HTTPS through your hosting provider.

GOOGLE:
A public, crawlable site with descriptive image captions/alt text can help Google understand your images.
Google Business Profile can also surface your verified ministry profile, photos and website in Search/Maps where eligible.
